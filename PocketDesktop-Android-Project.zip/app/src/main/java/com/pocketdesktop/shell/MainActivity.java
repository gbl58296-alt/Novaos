package com.pocketdesktop.shell;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        web = new WebView(this);
        web.setBackgroundColor(0xff101827);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Pocket");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    public class Bridge {
        @JavascriptInterface public void toast(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }
        @JavascriptInterface public void openBrowser() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "Não foi possível abrir o navegador.", Toast.LENGTH_SHORT).show(); }
            });
        }
        @JavascriptInterface public void openSettings() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "Configurações indisponíveis.", Toast.LENGTH_SHORT).show(); }
            });
        }
        @JavascriptInterface public void openFiles() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivity(i);
                } catch (Exception e) { Toast.makeText(MainActivity.this, "Gerenciador de arquivos indisponível.", Toast.LENGTH_SHORT).show(); }
            });
        }
        @JavascriptInterface public void openGames() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_MAIN, null);
                intent.addCategory(Intent.CATEGORY_LAUNCHER);
                PackageManager pm = getPackageManager();
                List<ResolveInfo> found = pm.queryIntentActivities(intent, 0);
                ArrayList<Intent> choices = new ArrayList<>();
                ArrayList<String> labels = new ArrayList<>();
                for (ResolveInfo ri : found) {
                    String pkg = ri.activityInfo.packageName.toLowerCase();
                    String label = ri.loadLabel(pm).toString();
                    String low = label.toLowerCase();
                    if (pkg.contains("winlator") || pkg.contains("exagear") || pkg.contains("game") ||
                        pkg.contains("emulator") || pkg.contains("termux") || low.contains("winlator") ||
                        low.contains("emulator") || low.contains("game")) {
                        Intent launch = pm.getLaunchIntentForPackage(ri.activityInfo.packageName);
                        if (launch != null && !labels.contains(label)) { choices.add(launch); labels.add(label); }
                    }
                }
                if (choices.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Instale primeiro um emulador compatível, depois tente novamente.", Toast.LENGTH_LONG).show();
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=pc%20game%20emulator&c=apps"))); } catch(Exception ignored) {}
                    return;
                }
                Intent chooser = Intent.createChooser(choices.get(0), "Abrir jogo ou emulador");
                if (choices.size() > 1) {
                    Intent[] extra = new Intent[choices.size()-1];
                    for (int i=1; i<choices.size(); i++) extra[i-1] = choices.get(i);
                    chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, extra);
                }
                startActivity(chooser);
            });
        }
    }
    @Override public void onBackPressed() {
        if (web != null) web.evaluateJavascript("backToDesktop()", null);
        else super.onBackPressed();
    }
}
